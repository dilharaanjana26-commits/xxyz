
        <script>
        window.location = "login.php";
        </script>
        