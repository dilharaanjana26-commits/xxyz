<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
    <title>Sign Up | Create Account</title>
    
    <link rel="stylesheet" href="assets/css/app.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/components.css">
    <link rel="stylesheet" href="assets/css/custom.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <style>
        :root {
            --primary: #667eea;
            --secondary: #764ba2;
            --gradient: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            --card-bg: rgba(255, 255, 255, 0.95);
            --dark-bg: #0f172a;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: var(--dark-bg);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow-x: hidden;
            position: relative;
            color: #333;
        }

        /* Animated Background */
        .gradient-mesh {
            position: fixed;
            top: 0; left: 0; width: 100%; height: 100%;
            z-index: -2;
            background: 
                radial-gradient(circle at 20% 30%, rgba(90, 103, 216, 0.15) 0%, transparent 50%),
                radial-gradient(circle at 80% 20%, rgba(124, 58, 237, 0.15) 0%, transparent 50%);
            animation: gradient-shift 15s ease-in-out infinite alternate;
        }

        @keyframes gradient-shift {
            0% { background-position: 0% 0%; }
            100% { background-position: 100% 100%; }
        }
        
        .particles-container { position: fixed; width: 100%; height: 100%; z-index: -1; }
        .particle {
            position: absolute; background: var(--gradient); border-radius: 50%;
            filter: blur(1px); animation: float 20s infinite linear;
        }
        @keyframes float {
            0% { transform: translateY(100vh) rotate(0deg); opacity: 0; }
            50% { opacity: 0.5; }
            100% { transform: translateY(-100px) rotate(360deg); opacity: 0; }
        }

        /* Card Styling */
        .auth-container { width: 100%; max-width: 480px; margin: 20px; position: relative; }
        
        .auth-card {
            background: var(--card-bg);
            backdrop-filter: blur(20px);
            border-radius: 24px;
            padding: 40px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.1);
            border: 1px solid rgba(255, 255, 255, 0.5);
            position: relative;
            overflow: hidden;
        }

        .auth-card::before {
            content: ''; position: absolute; top: 0; left: 0; right: 0; height: 4px;
            background: var(--gradient);
        }

        .auth-header { text-align: center; margin-bottom: 30px; }
        .auth-header h1 { font-size: 28px; font-weight: 700; color: #333; margin-bottom: 5px; }
        .auth-header p { font-size: 14px; color: #666; }

        .logo-icon {
            width: 60px; height: 60px; background: var(--gradient); border-radius: 50%;
            display: flex; align-items: center; justify-content: center; margin: 0 auto 20px;
            color: white; font-size: 24px; box-shadow: 0 10px 20px rgba(102, 126, 234, 0.3);
        }

        /* Form */
        .form-group { margin-bottom: 20px; position: relative; }
        .form-label { font-weight: 600; font-size: 13px; color: #555; margin-bottom: 8px; display: block; }
        
        .input-group-text {
            background: #f8fafc; border-color: #e2e8f0; color: #64748b; border-radius: 10px 0 0 10px;
        }
        
        .form-control {
            border-color: #e2e8f0; border-radius: 0 10px 10px 0; padding: 12px 15px; height: 50px; font-size: 14px;
        }
        
        .form-control:focus {
            border-color: #667eea; box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }

        .btn-register {
            background: var(--gradient); border: none; color: white; padding: 15px;
            border-radius: 12px; font-weight: 600; font-size: 16px; width: 100%;
            cursor: pointer; transition: transform 0.2s, box-shadow 0.2s;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.3);
        }
        
        .btn-register:hover { transform: translateY(-2px); box-shadow: 0 8px 25px rgba(102, 126, 234, 0.4); }

        .auth-footer { text-align: center; margin-top: 25px; font-size: 14px; color: #777; }
        .auth-footer a { color: #667eea; font-weight: 600; text-decoration: none; }
        
        /* Alert */
        .alert { border-radius: 10px; font-size: 13px; padding: 12px; margin-bottom: 20px; border: none; display: flex; align-items: center; gap: 10px; }
        .alert-danger { background: #fff5f5; color: #c53030; border-left: 4px solid #fc8181; }
        
        .security-badge {
            margin-top: 25px; padding: 12px; background: #f1f5f9; border-radius: 10px;
            text-align: center; font-size: 12px; color: #64748b; display: flex;
            align-items: center; justify-content: center; gap: 8px;
        }
    </style>
</head>

<body>
    <div class="gradient-mesh"></div>
    <div class="particles-container" id="particles"></div>

    <div class="auth-container animate__animated animate__fadeIn">
        <div class="auth-card">
            <div class="auth-header">
                <div class="logo-icon"><i class="fas fa-user-plus"></i></div>
                <h1>Create Account</h1>
                <p>Join us to manage your licenses seamlessly</p>
                
            </div>

            
            <form method="POST" id="signupForm">
                <div class="form-group">
                    <label class="form-label">Username</label>
                    <div class="input-group">
                        <div class="input-group-prepend">
                            <span class="input-group-text"><i class="fas fa-user"></i></span>
                        </div>
                        <input type="text" class="form-control" name="name" placeholder="Username" required>
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label">Email Address</label>
                    <div class="input-group">
                        <div class="input-group-prepend">
                            <span class="input-group-text"><i class="fas fa-envelope"></i></span>
                        </div>
                        <input type="email" class="form-control" name="email" placeholder="name@example.com" required>
                    </div>
                    <small class="text-muted mt-1 d-block"><i class="fas fa-info-circle"></i> Password will be sent to this email.</small>
                </div>

                <div class="form-group">
                    <label class="form-label">WhatsApp Number</label>
                    <div class="input-group">
                        <div class="input-group-prepend">
                            <span class="input-group-text"><i class="fas fa-phone"></i></span>
                        </div>
                        <input type="tel" class="form-control" name="mobile" id="mobile" placeholder="+919876543210" required>
                    </div>
                    <small class="text-muted mt-1 d-block"><i class="fas fa-check-circle"></i> Include Country Code (e.g. +91)</small>
                </div>

                <button type="submit" class="btn-register" id="submitBtn">
                    Register Now <i class="fas fa-arrow-right ml-2"></i>
                </button>
            </form>

            <div class="security-badge">
                <i class="fas fa-lock text-success"></i> 
                <span>Your data is secure. No spam, we promise.</span>
            </div>

            <div class="auth-footer">
                Already have an account? <a href="login.php">Log In</a>
            </div>
        </div>
    </div>

    <script src="assets/js/app.min.js"></script>
    <script>
        // Particles
        const container = document.getElementById('particles');
        for (let i = 0; i < 20; i++) {
            const p = document.createElement('div');
            p.className = 'particle';
            p.style.width = Math.random() * 50 + 10 + 'px';
            p.style.height = p.style.width;
            p.style.left = Math.random() * 100 + '%';
            p.style.top = Math.random() * 100 + '%';
            p.style.animationDelay = Math.random() * 5 + 's';
            p.style.animationDuration = Math.random() * 20 + 10 + 's';
            container.appendChild(p);
        }

        // Mobile Validation & Submit Animation
        document.getElementById('signupForm').addEventListener('submit', function(e) {
            const mobile = document.getElementById('mobile').value;
            const btn = document.getElementById('submitBtn');
            
            // Regex for E.164 format (e.g. +919876543210)
            const phoneRegex = /^\+[1-9]\d{1,14}$/;

            if (!phoneRegex.test(mobile)) {
                e.preventDefault();
                alert("Please enter a valid WhatsApp number with Country Code (e.g. +91...)");
                return false;
            }

            // Show Loading
            btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing...';
            btn.style.opacity = '0.7';
            btn.disabled = true;
        });
    </script>
</body>
</html>